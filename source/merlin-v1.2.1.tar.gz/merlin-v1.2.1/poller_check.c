#include <stdio.h>

int main(int argc, char **argv)
{
	printf("POLLER WAS HERE|poller=1;3;5;0;\n");

	return 0;
}
