#include <stdio.h>

int main(int argc, char **argv)
{
	printf("THE NOC DID IT|noc=5;3;1;0;\n");

	return 0;
}
