import os, sys, re, time

modpath = os.path.dirname(os.path.abspath(__file__)) + '/modules'
if not modpath in sys.path:
	sys.path.append(modpath)
from merlin_apps_utils import *
import merlin_db

wanted_types = []
wanted_names = []
have_type_arg = False
have_name_arg = False

def module_init(args):
	global wanted_types, wanted_names
	global have_type_arg, have_name_arg

	wanted_types = mconf.merlin_node.valid_types
	rem_args = []
	i = -1
	for arg in args:
		i += 1
		# stop parsing immediately if we hit double-dashes, or we
		# may well break recursive commands sent with mon node ctrl.
		if arg == '--':
			rem_args += args[i:]
			break
		if arg.startswith('--merlin-cfg=') or arg.startswith('--config='):
			mconf.config_file = arg.split('=', 1)[1]
		elif arg.startswith('--type='):
			wanted_types = arg.split('=')[1].split(',')
			have_type_arg = True
		elif arg.startswith('--name='):
			wanted_names = arg.split('=')[1].split(',')
			have_name_arg = True
		else:
			# not an argument we recognize, so stash it and move on
			rem_args += [arg]
			continue

	# load the merlin configuration, and thus all nodes
	mconf.parse()
	return rem_args

def get_min_avg_max(table, column, iid=None):
	query = 'SELECT min(%s), avg(%s), max(%s) FROM %s WHERE ' % \
		(column, column, column, table)

	if iid != None:
		query += 'instance_id = %d AND ' % iid

	query += 'active_checks_enabled = 1'

	dbc.execute(query)
	row = dbc.fetchone()
	ret = {'min': row[0], 'avg': row[1], 'max': row[2]}
	return ret

def get_num_checks(table, iid=None):
	query = 'SELECT count(*) FROM %s' % table
	if iid != None:
		query += ' WHERE instance_id = %d' % iid

	dbc.execute(query)
	row = dbc.fetchone()
	return row[0]

def get_node_status():
	global dbc

	cols = {
		'instance_name': False, 'instance_id': False,
		'is_running': False, 'last_alive': False,
	}

	dbc.execute("select %s "
		"FROM program_status ORDER BY instance_name" % ', '.join(cols.keys()))

	result_set = {}
	for row in dbc.fetchall():
		res = {}
		node_name = row[0]
		col_num = 1
		for col in cols.keys()[1:]:
			res[col] = row[col_num]
			col_num += 1

		result_set[node_name] = res

	for (name, info) in result_set.items():
		iid = info['instance_id']
		for otype in ['host', 'service']:
			info['%s_checks' % otype] = get_num_checks(otype, iid)
			info['%s_latency' % otype] = get_min_avg_max(otype, 'latency', iid)
			info['%s_exectime' % otype] = get_min_avg_max(otype, 'execution_time', iid)

	return result_set

def fmt_min_avg_max(lat, thresh={}):
	values = []
	keys = []
	for (k, v) in lat.items():
		if v == None:
			continue
		v_color = ''
		max_v = thresh.get(k, -1)
		if max_v >= 0 and max_v < v:
			v_color = color.red
		keys.insert(0, k)
		values.insert(0, "%s%.3f%s" % (v_color, v, color.reset))

	if not values and not keys:
		return ": %s%s%s" % (color.red, "Unable to retrieve data", color.reset)
	
	ret = "(%s): %s" % (' / '.join(keys), ' / '.join(values))
	return ret

dbc = False
def cmd_status(args):
	"""
	Show status of all nodes configured in the running Merlin daemon
	Red text points to problem areas, such as high latency or the node
	being inactive, not handling any checks,  or not sending regular
	enough program_status updates.
	"""
	global dbc

	high_latency = {}
	inactive = {}
	mentioned = {}

	dbc = merlin_db.connect(mconf).cursor()

	status = get_node_status()
	latency_thresholds = {'min': -1.0, 'avg': 100.0, 'max': -1.0}
	sinfo = sorted(status.items())
	host_checks = get_num_checks('host')
	service_checks = get_num_checks('service')
	print("Total checks (host / service): %d / %d" % (host_checks, service_checks))

	num_peers = mconf.num_nodes['peer']
	num_pollers = mconf.num_nodes['poller']
	num_masters = mconf.num_nodes['master']
	num_helpers = num_peers + num_pollers
	for (name, info) in sinfo:
		print("")
		iid = info.pop('instance_id', 0)
		node = mconf.configured_nodes.get(name, False)
		is_running = info.pop('is_running')
		name = "#%02d: %s" % (iid, name)
		name_len = len(name) + 9
		if is_running:
			name += " (%sACTIVE%s)" % (color.green, color.reset)
		else:
			name += " (%sINACTIVE%s)" % (color.red, color.reset)
			name_len += 2

		print("%s\n%s" % (name, '-' * name_len))
		if iid and not node:
			print("%sThis node is currently not in the configuration file%s" %
				(color.yellow, color.reset))

		last_alive = info.pop('last_alive')
		if not last_alive:
			print("%sUnable to determine when this node was last alive%s" %
				(color.red, color.reset))
		else:
			if last_alive + 30 > time.time():
				la_color = color.green
			else:
				la_color = color.red

			delta = time_delta(last_alive)
			dtime = time.strftime("%F %H:%M:%S", time.localtime(last_alive))
			print("Last alive: %s (%d) (%s%s ago%s)" %
				(dtime,	last_alive, la_color, delta, color.reset))

		hchecks = info.pop('host_checks')
		schecks = info.pop('service_checks')
		hc_color = sc_color = ''

		# master nodes should never run checks
		hc_color = ''
		sc_color = ''
		if node:
			# if the node is a master and it's running checks,
			# that's an error
			if node.ntype == 'master':
				if hchecks:
					hc_color = color.red
				if schecks:
					sc_color = color.red
			else:
				# if it's not and it's not running checks,
				# that's also an error
				if not hchecks:
					hc_color = color.red
				if not schecks:
					sc_color = color.red

		# if this is the local node, we have helpers attached
		# and we're still running all checks, that's bad
		if not iid and num_helpers:
			if hchecks == host_checks:
				hc_color = color.red
			if schecks == service_checks:
				sc_color = color.red

		hpercent = 0
		if host_checks != 0:
			hpercent = float(hchecks) / float(host_checks) * 100
		spercent = 0
		if service_checks != 0:
			spercent = float(schecks) / float(service_checks) * 100

		print("Checks (host/service): %s%d%s / %s%d%s  (%s%.2f%%%s / %s%.2f%%%s)" %
			(hc_color, hchecks, color.reset, sc_color, schecks, color.reset,
			hc_color, hpercent, color.reset,
			sc_color, spercent, color.reset))

		# if this node has never reported any checks, we can't
		# very well print out its latency or execution time values
		if not hchecks and not schecks:
			continue
		host_lat = fmt_min_avg_max(info.pop('host_latency'), latency_thresholds)
		service_lat = fmt_min_avg_max(info.pop('service_latency'), latency_thresholds)
		host_exectime = fmt_min_avg_max(info.pop('host_exectime'))
		service_exectime = fmt_min_avg_max(info.pop('service_exectime'))
		print("Host latency    %s" % host_lat)
		print("Service latency %s" % service_lat)
		#print("Host check execution time    %s" % host_exectime)
		#print("Service check execution time %s" % service_exectime)

		# should be empty by now
		for (k, v) in info.items():
			print("%s = %s" % (k, v))

	merlin_db.disconnect()

## node commands ##
# list configured nodes, capable of filtering by type
def cmd_list(args):
	"""[--type=poller,peer,master]
	Lists all nodes of the (optionally) specified type
	"""
	global wanted_types
	for node in mconf.configured_nodes.values():
		if not node.ntype in wanted_types:
			continue
		print("  %s" % node.name)


def cmd_show(args):
	"""[--type=poller,peer,master]
	Display all variables for all nodes, or for one node in a fashion
	suitable for being used as
	  eval $(mon node show nodename)
	from shell scripts and scriptlets
	"""

	if len(mconf.configured_nodes) == 0:
		print("No nodes configured")
		return
	if len(args) == 0:
		names = mconf.configured_nodes.keys()
		names.sort()
		for name in names:
			node = mconf.configured_nodes[name]
			if not node.ntype in wanted_types:
				continue
			print("\n# %s" % name)
			node.show()

	for arg in args:
		if not arg in mconf.configured_nodes.keys():
			print("'%s' is not a configured node. Try the 'list' command" % arg)
			# scripts will list one node at a time. If the command
			# fails, they don't have to check the output to see if
			# the got anything sensible or not
			if len(args) == 1:
				sys.exit(1)
			continue
		if not mconf.configured_nodes[arg].ntype in wanted_types:
			continue
		if len(args) > 1:
			print("\n# %s" % arg)
		mconf.configured_nodes[arg].show()


def cmd_add(args):
	"""<name> type=[peer|poller|master] [var1=value] [varN=value]
	Adds a node with the designated type and variables
	"""
	if len(args) < 1:
		return False
	name = args[0]
	if name in mconf.configured_nodes.keys():
		print("%s is already configured. Aborting" % name)
		return False

	node = mconf.merlin_node(name)
	node.path = mconf.config_file

	for arg in args[1:]:
		if not '=' in arg:
			continue
		ary = arg.split('=', 1)
		node.set(ary[0], ary[1])

	if node.save():
		print("Successfully added %s node '%s'" % (node.ntype, node.name))
		return True

	print("Failed to add %s node '%s'" % (node.ntype, node.name))
	return False


def _cmd_edit(args):
	if len(args) < 2:
		print("No key=value pairs to modify")
		return False

	name = args[0]
	if not name in mconf.configured_nodes.keys():
		print("%s isn't configured yet. Use 'add' to add it" % name)
		return False

	node = mconf.merlin_node(args[0])
	for arg in args[1:]:
		node.set(arg)

	return node.save()


def cmd_remove(args):
	"""<name1> [name2] [nameN]
	Removes one or more nodes from the merlin configuration.
	"""
	if len(args) == 0:
		print("Which node do you want to remove? Try the 'list' command")
		return

	for arg in args:
		if not arg in mconf.configured_nodes:
			print("'%s' is not a configured node. Try the 'list' command" % arg)
			continue

		node = mconf.configured_nodes.pop(arg)
		sed_range = str(node.comp.line_start) + ',' + str(node.comp.line_end)
		cmd_args = ['sed', '-i', sed_range + 'd', mconf.config_file]
		os.spawnvp(os.P_WAIT, 'sed', cmd_args)


def cmd_ctrl(args):
	"""<name1> <name2> [--self] [--all|--type=<peer|poller|master>] -- <command>
	Execute <command> on the remote node(s) named. --all means run it on
	all configured nodes, as does making the first argument '--'.
	--type=<types> means to run the command on all configured nodes of
	the given type(s).
	The first not understood argument marks the start of the command,
	but always using double dashes is recommended. Use single-quotes
	to execute commands with shell variables, output redirection or
	scriptlets, like so:
	  mon node ctrl -- '(for x in 1 2 3; do echo $x; done) > /tmp/foo'
	  mon node ctrl -- cat /tmp/foo
	"""

	global wanted_names

	if len(args) == 0:
		print("Control without commands seems quite pointless. I'm going home")
		print("Try 'mon node help' for some assistance")
		sys.exit(1)

	run_on_self = False
	by_name = False
	nodes = {}
	cmd_args = []
	i = -1
	for arg in args:
		i += 1
		if arg == '--all':
			wanted_names = mconf.configured_nodes.keys()
			continue
		elif arg == '--self':
			run_on_self = True
			continue
		elif arg == '--':
			# double dashes means "here's the command"
			cmd_args = args[i + 1:]
			# if it's the first argument we got, the user wants
			# to run the command on all configured nodes, possibly
			# including --self
			if not len(wanted_names):
				wanted_names = mconf.configured_nodes.keys()
			break

		node = mconf.configured_nodes.get(arg, False)
		if node == False:
			cmd_args = args[i:]
			break
		wanted_names += [node.name]
		by_name = True

	if have_type_arg and not len(wanted_names):
		wanted_names = mconf.configured_nodes.keys()

	for name in wanted_names:
		node = mconf.configured_nodes.get(name, False)
		if not node:
			print("%s is not a configured node. Aborting" % name)
			sys.exit(1)

		# check type and add it if we want it
		if node.ntype in wanted_types:
			nodes[name] = node

	if (not len(nodes) or not len(cmd_args)) and not run_on_self:
		print("No nodes, or no commands to send. Aborting")
		sys.exit(1)

	cmd = ' '.join(cmd_args)
	if run_on_self:
		os.spawnvp(os.P_WAIT, "/bin/sh", ["/bin/sh", "-c", cmd])

	for name, node in nodes.items():
		if str(node.connect) != "no":
			node.ctrl(cmd)

	if by_name and len(wanted_names) == 1:
		sys.exit(node.get_exit_code())

def _cmd_rename(args):
	if len(args) != 2 or not args[0] in mconf.configured_nodes.keys():
		print("Which node do you want to rename? Try the 'list' command")
		return False

	node = mconf.configured_nodes[args[0]]
	dest = args[1]
	if dest in mconf.configured_nodes.keys():
		print("A node named '%s' already exists. Remove it first" % dest)
		return False
	mconf.configured_nodes.pop(args[0])
	mconf.configured_nodes[dest] = node
	node.rename(dest)
