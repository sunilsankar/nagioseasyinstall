#!/bin/sh

/etc/init.d/monitor stop
/etc/init.d/monitor slay
/etc/init.d/merlind stop
