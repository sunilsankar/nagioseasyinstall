ALTER TABLE avail_config ADD include_trends BOOLEAN default 1;
