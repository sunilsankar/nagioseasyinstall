ALTER TABLE avail_config CHANGE user username VARCHAR(255) NOT NULL;
