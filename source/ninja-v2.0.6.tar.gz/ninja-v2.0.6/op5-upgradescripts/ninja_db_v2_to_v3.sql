ALTER TABLE ninja_widgets CHANGE COLUMN user username varchar(200) NOT NULL;
ALTER TABLE ninja_settings CHANGE COLUMN user username varchar(200) NOT NULL;
