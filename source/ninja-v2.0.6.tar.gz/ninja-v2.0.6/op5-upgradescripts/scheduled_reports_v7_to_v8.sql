ALTER TABLE scheduled_reports ADD local_persistent_filepath VARCHAR(200);
