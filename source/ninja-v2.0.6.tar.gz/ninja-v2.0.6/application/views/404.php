<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<div align="center" style="padding-top:10px;">
	<?php echo html::image('application/views/themes/default/icons/icon.png',''); ?><br /><br />

	<?php echo $this->translate->_('404 Not Found'); ?><br /><br />

	<?php echo $this->translate->_('Ooops, the page you requested could not be found.'); ?><br />
	<?php echo $this->translate->_('Please contact your administrator.'); ?>
</div>