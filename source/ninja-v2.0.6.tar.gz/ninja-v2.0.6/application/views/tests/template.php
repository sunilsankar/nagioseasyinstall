<?php

echo isset($content) ? $content : "no data\n";