<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<p>
	<?php echo $error_msg ?>
</p>
<p>
	<?php echo $error_description ?>
</p>