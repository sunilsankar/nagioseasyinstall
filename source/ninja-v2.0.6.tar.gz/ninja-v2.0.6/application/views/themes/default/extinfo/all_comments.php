<?php defined('SYSPATH') OR die('No direct access allowed.');
if (isset($host_comments))
	echo $host_comments;

echo "<br /><br />";

if (isset($service_comments))
	echo $service_comments;
