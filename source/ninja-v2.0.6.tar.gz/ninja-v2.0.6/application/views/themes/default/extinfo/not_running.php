<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<div style="padding:13px">
	&nbsp;<?php echo $info_message ?><br />
	<?php echo isset($info_message_extra) ? $info_message_extra : '' ?>
</div>
