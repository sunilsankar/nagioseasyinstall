<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>
<br />

	<div class="error_message">
		<?php echo $error_message ?>
	</div>

	<div class="error_description">
		<?php echo $error_description ?>
	</div>