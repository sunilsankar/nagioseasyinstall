<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<p>
	<div class='errorMessage'>
		<?php echo $error_message ?>
	</div>
</p>
