$(document).ready(function() {
	$("input:visible:enabled:first").focus();
});