<span class="<?php echo $status ? 'ok' : 'error'; ?>"><?php echo $message; ?></span>
<span id="backupfilename" class="hidden"><?php echo $file; ?></span>
