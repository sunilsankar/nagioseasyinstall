<span class="<?php echo $status ? 'ok' : 'error'; ?>"><?php echo $message; ?></span>
