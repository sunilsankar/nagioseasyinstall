<?php defined('SYSPATH') OR die('No direct access allowed.'); ?>

<div style="margin-left: 1px; ">
	<iframe name="nagvis" id="nagvis" src="/nagvis/nagvis/?map=<?php echo $map; ?>" width="100%">
		Error : Can not load NagVis.
	</iframe>
</div>
