/*==================================================
 *  Localization of labellers.js
 *==================================================
 */

Timeline.GregorianDateLabeller.monthNames["tr"] = [
    "Ock", "Şbt", "Mrt", "Nsn", "Mys", "Hzr", "Tem", "Ağs", "Eyl", "Ekm", "Ksm", "Arl"
];
