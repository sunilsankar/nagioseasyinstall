<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
* 	This flag controls visibility of links to old GUI (CGIs)
*/
$config['show_cgi_links'] = false;
