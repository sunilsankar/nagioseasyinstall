#!/usr/bin/php

This script has been replaced with the Kohana unit test named ninja_unit_test/wipe_tables,
to allow us to use the same DB framework which Ninja uses.

<?php
exit(1);
?>
